import {PHOTOS_FAIL, PHOTOS_SUCCESS, POSTS_FAIL, POSTS_SUCCESS, photos_posts_url} from './../constants/photosConstants'
import axios from 'axios';

export const photosSuccess=(photos)=>{
    return{
        type:PHOTOS_SUCCESS,
        payload:photos
    }
}

export const photosFail=(err)=>{
    return{
        type:PHOTOS_FAIL,
        payload:err
    }
}

export const postsSuccess=(posts)=>{
    return{
        type:POSTS_SUCCESS,
        payload:posts
    }
}

export const postsFail=(err)=>{
    return{
        type:POSTS_FAIL,
        payload:err
    }
}

export const photosRequest=()=>{
    return dispatch=>{
        axios({
            url:`${photos_posts_url}/photos`,
            method:'GET'
        })
        .then(res=>{dispatch(photosSuccess(res.data))})
        .catch(err=>{dispatch(photosFail(err))})
    }
}
export const postsRequest=()=>{
    return dispatch=>{
        axios({
            url:`${photos_posts_url}/posts`,
            method:'GET'
        })
        .then(res=>{dispatch(photosSuccess(res.data))})
        .catch(err=>{dispatch(photosFail(err))})
    }
}