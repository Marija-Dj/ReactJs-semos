import React, { Component } from 'react'
import {connect} from 'react-redux';
import {photosRequest} from './../actions/photosAction'
export class Photos extends Component {
    render() {
        return (
            <div>{
                          this.props.photos.slice(0, 50).map(photo=>{
                        return(
                            <div key={photo.id}>
                                <img src={photo.thumbnailUrl} alt={photo.title}/>

                            </div>
                        )

                    })
                 }
            </div>
        )
    }
}
const mapStateToProps = (state) =>{
    return {
        photos:state.photosReducers.posts,
        err:state.photosReducers.err
    }
}

const mapDispatchToProps = (dispatch) =>{
    return{
        phostos: ()=>{
            dispatch(photosRequest())
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Photos)
//export default Photos
