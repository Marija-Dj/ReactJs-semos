import React, { Component } from 'react'
import {Switch, Route} from 'react-router-dom'
import Nav from './Nav'
import { Photos } from './Photos'
import { Posts } from './Posts'


export class App extends Component {
  render() {
    return (
      <div>
        <Nav/>
        <Switch>
          <Route path="/" component={App}/>
          <Route path="/posts" component={Posts}/>
          <Route path="/photos" component={Photos}/>
        </Switch>
        <h1>HI</h1>
      </div>
    )
  }
}

export default App

