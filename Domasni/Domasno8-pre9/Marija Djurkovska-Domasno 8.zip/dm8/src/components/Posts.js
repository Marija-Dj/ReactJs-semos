import React, { Component } from 'react'
import {connect} from 'react-redux';
import {postsRequest} from './../actions/photosAction'
export class Posts extends Component {
    render() {
        return (
            <div>
                                                                {
                    this.props.posts.length>1?
                    <table border= "5">
                        <thead>
                            <tr>
                                <th>
                                    UserId
                                </th>
                                <th>
                                    Id
                                </th>
                                <th>
                                    Title
                                </th>
                                <th>body</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.props.posts.map((post, i)=>{
                                    return(
                                        <tr key={i}>
                                            <td>{post.userId}</td>
                                            <td>{post.id}</td>
                                            <td>{post.title}</td>
                                    <td>{post.body}</td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>  : <h2>Loading..</h2>}
                
            </div>
        )
    }
}

const mapStateToProps = (state) =>{
    return {
        posrs:state.postsReducer.posts,
        err:state.postsReducer.err
    }
}

const mapDispatchToProps = (dispatch) =>{
    return{
        posts: ()=>{
            dispatch(postsRequest())
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Posts)
//export default Posts
