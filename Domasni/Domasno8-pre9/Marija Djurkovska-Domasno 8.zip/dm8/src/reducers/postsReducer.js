import {POSTS_FAIL, POSTS_SUCCESS} from './../constants/photosConstants'

const initialState={
    posts:[],
    err:""
}

const PostsReducer=(state=initialState, action)=>{
    switch(action.type){
        case POSTS_SUCCESS:
            return {
                ...state,
                posts: action.payload
            }
        case POSTS_FAIL:
            return{
                ...state,
                err: action.payload 
            }
        default: return state;
    }
}

export default PostsReducer;
