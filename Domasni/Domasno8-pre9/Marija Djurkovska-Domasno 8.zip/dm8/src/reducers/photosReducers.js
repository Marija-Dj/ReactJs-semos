import {PHOTOS_SUCCESS, PHOTOS_FAIL} from './../constants/photosConstants'

const initialState={
    photos:[],
    err:""
}

const PhotosReducer=(state=initialState, action)=>{
    switch(action.type){
        case PHOTOS_SUCCESS:
            return {
                ...state,
                photos: action.payload
            }
        case PHOTOS_FAIL:
            return{
                ...state,
                err: action.payload 
            }
        default: return state;
    }
}

export default PhotosReducer;
