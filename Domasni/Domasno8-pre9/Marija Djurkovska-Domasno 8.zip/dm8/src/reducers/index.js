import {combineReducers} from 'redux'
import photosReducers from './photosReducers'
import postsReducer from './postsReducer'
export default combineReducers({
    photosReducers, postsReducer
})