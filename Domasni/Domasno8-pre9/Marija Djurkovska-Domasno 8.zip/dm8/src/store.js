import {createStore, applyMiddleware} from 'redux'
import{createLogger} from 'redux-logger'
import thank from 'redux-thunk'
import combine from './reducers'
const middleware= applyMiddleware(thank,createLogger());
export default createStore(combine,middleware)