import React from 'react'
import { Input } from './Input';
import './Css.css';

export class CheckoutForm extends React.Component {
    constructor(props)
    {
        super();
        this.state={
            firstName:"",
            lastName:"",
            username:"",
            email:"",
            address:"",
            //country:"",
            city:"",
            zip:"",
            //payment:"",
            nameOfCard:"",
            creditCardNumber:"",
            expiration:"",
            cvv:"",
            inputeType:"text",
            show:false
        }
      this.onValueRadio = this.onValueRadio.bind(this);
      this.onValueSelect=this.onValueSelect.bind(this);
     // this.onValueCity=this.onValueCity.bind(this);
    }
    inputeChangeHandler=(event)=>{
        this.setState({
            [event.target.name]:event.target.value   
        })
    }
    onValueRadio=(e)=>
    {
        this.setState({
            payment:e.target.value
        });
    }
    onValueSelect = (e)=>
    {
        this.setState({
            country:e.target.value
            
        })
    }
    taggVis =() =>{
        this.setState({
            show:!this.state.show
        })
    }
    
    inputTypeChange=()=>
    {
        this.setState({
        inputeType: this.state.inputeType==="text"?"email":this.state.inputeType==="email"?"text":this.state.inputeType==="text"?"radio":this.state.inputeType==="radio"?"number":"pasword"
        })
    }
    hideShow=()=>{
        this.setState({

        })
    }

    render() {
        console.log(this.state);
        console.log(this.state.payment);
        console.log(this.state.country);
        console.log(this.state.city)
        return (
            <div id="CheckoutForm">
                <h1>Checkout Form</h1>
                <form>
                     {//onSubmit={this.formSubmit} id="form"
                     }
                <label>First Name</label>
                    <Input
                    type="text"
                    value={this.state.firstName}
                    name="firstName"
                    placeholder="Enter your First Name"
                    onChange={this.inputeChangeHandler}
                    /> <br/>
                    <label>Last Name</label>
                     <Input
                    type="text"
                    value={this.state.lastName}
                    name="lastName"
                    placeholder="Enter your Last Name"
                    onChange={this.inputeChangeHandler}
                    /> <br/>
                    <label>Username</label>
                     <Input
                    type="text"
                    value={this.state.username}
                    name="username"
                    placeholder="Username"
                    onChange={this.inputeChangeHandler}
                    /> <br/>
                    <label>Email</label>
                    <Input
                    type="email"
                    value={this.state.email}
                    name="email"
                    placeholder="you@example.com"
                    onChange={this.inputeChangeHandler}
                    /><br/>
                    <label>Address</label>
                    <Input
                    type={this.state.inputeType}
                    value={this.state.address}
                    name="address"
                    placeholder="ul. leninova br. 44"
                    onChange={this.inputeChangeHandler}
                    />  
                    <br/>
                    <label>Country</label>
                    <select name="country" onChange={this.onValueSelect}>
                        <option value="Macedonia">Macedonia</option>
                        <option value="Serbia">Serbia</option>
                        <option value="Croatia">Croatia</option>

                    </select>
                    <br/>
                    <label>City</label>
                    <Input
                      type={this.state.inputeType}
                      value={this.state.city}
                      name="city"
                      placeholder=""
                       onChange={this.inputeChangeHandler}
                    /><br/>
                     <label>Zip</label>
                    <Input
                      type="number"
                      value={this.state.zip}
                      name="zip"
                      placeholder=""
                       onChange={this.inputeChangeHandler}
                    />


                    <hr/>
                    
                    <h2>Payment</h2>
                    <label>
                    <Input
                     //defaultChecked
                    type="radio"
                    value="Credit cart"
                    name="payment"
                    checked={this.state.payment === "Credit cart"}
                    //checked={true}
                    onChange={this.onValueRadio}
                    /> Credit cart </label>
                    <br/>
                  <label>
                    <Input
                    // defaultChecked
                    type="radio"
                    value="PayPa"
                    name="payment"
                    //checked={}
                    onChange={this.onValueRadio}
                    /> PayPal </label>
                    <br/>
                  <label>
                    <Input
                    // defaultChecked
                    type="radio"
                    value="Debit card"
                    name="payment"
                    //checked={}
                    onChange={this.onValueRadio}
                    /> Debit card </label>
                    <br/><hr/>
                    <label>Name on card</label>
                    <Input
                    type="text"
                    value={this.state.nameOfCard}
                    name="nameOfCard"
                    onChange={this.inputeChangeHandler}
                    />
                    <label>Credit card number</label>
                    <Input

                    type="number"
                    value={this.state.creditCardNumber}
                    name="creditCardNumber"
                    onChange={this.inputeChangeHandler}
                    />               
                     <label>Expiration</label>
                    <Input

                    type="number"
                    value={this.state.expiration}
                    name="expiration"
                    onChange={this.inputeChangeHandler}
                    />
                  <button type="button"  class="button button1"  onClick= {(this.taggVis)}> 
              {this.state.show? 'Hide' : 'Show'}</button>
                </form>
                <hr/>
     {  this.state.show&&
             <table>
                    <thead id="h">
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Country</th>
                        <th>City</th>
                        <th>Zip</th>
                        <th>Payment</th>
                        <th>Name of card</th>
                        <th>Credit card number</th>
                        <th>Expiration</th>
                    </thead>
                    <tbody id="b">
                        <tr>
                           <td>{this.state.firstName}</td>
                            <td>{this.state.lastName}</td>
                            <td>{this.state.username}</td>      
                            <td>{this.state.email}</td>         
                            <td>{this.state.address}</td>         
                            <td>{this.state.country}</td>         
                            <td>{this.state.city}</td>
                            <td>{this.state.zip}</td>         
                            <td>{this.state.payment}</td>         
                            <td>{this.state.nameOfCard}</td>                            
                            <td>{this.state.creditCardNumber}</td>
                            <td>{this.state.expiration}</td>
                        </tr>
                    </tbody>
                </table>}
            </div>
        )
    }
}
