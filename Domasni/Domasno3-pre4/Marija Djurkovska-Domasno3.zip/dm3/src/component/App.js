import React from 'react';
//import logo from './logo.svg';
import './App.css';
import { CheckoutForm } from './CheckoutForm';

export class App extends React.Component {
  render()
  {
  return (
    <div>
      <CheckoutForm/>
    </div> );}
};

