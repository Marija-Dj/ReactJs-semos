import React from 'react'

export class Input extends React.Component {
    render() {
        return (

                <input
                type={this.props.type}
                name={this.props.name}
                value={this.props.value}
                placeholder={this.props.placeholder}
                onChange={this.props.onChange}
                checked={this.props.checked}
                />

        )
    }
}
