import React from 'react';
//import logo from './logo.svg';
import './App.css';
import { Forms } from './Forms';


export class App extends React.Component{
  
     render()
     {
       console.log("Render")
       console.log(this.state)
     
     return (<div>
       <Forms/>

       </div>
       );
   }
   }
