import React from 'react'
import './forms.css';


export  class Forms extends React.Component {
    constructor(props){
        super()
        this.state={
         userName:"",
         userLastName:"",
         userEmail:"",
         userPass:"",
         age:"",
         show:true
        }
      }
        inputChangeHandler=(event)=>
        {
          this.setState({
            [event.target.name]:event.target.value
          })
       
        }
       
        showValues=(username, lastName, emails, password, userage)=>{
         alert(`Username: ${username}\n Last Name:${lastName}\n Email:${emails}\n  Password:${password}\n Age:${userage}\n`)
    
        }
         render()
         {
          // console.log("Render")
           //console.log(this.state)
        return (
            <div id="form">
                       <h1>Form</h1>
      <form id="survey-form">
			<label id="name-label" >Name</label>
				<input type="text" name="userName"  placeholder="Enter your name"  id="name" onChange={this.inputChangeHandler}  required/>

            <label id="lastName-label" >Last Name</label>
				<input type="text" name="userLastName"  placeholder="Enter your last name"  id="lastName" onChange={this.inputChangeHandler}  required/>
			
        <label id="email-label"> Email</label>
			<input type="email" name="userEmail" placeholder="Enter your emil" id="email" onChange={this.inputChangeHandler} required/>
            
            <label id="password-label">Password</label><br/>
      <input type="password" name="userPass"placeholder="Enter your Password"  onChange={this.inputChangeHandler} required/>

      <label id="number-label"> Age</label>
				<input type="number" name="age" placeholder="Enter your age" id="age"  max="150" min="1"  onChange={this.inputChangeHandler} required/> 
                <button class="button button1" type="submit" onClick={()=>{this.showValues(this.state.userName, this.state.userLastName, this.state.userEmail, this.state.userPass, this.state.age)}}>Submit Value</button>
                <button  class="button button1"  onClick={()=>{this.setState({show:!this.state.show})}}>{ this.state.show? 'Hide' : 'Show'} Table</button>
                
			
      	</form>
          <hr/>
{  this.state.show?  
          <table>
              
                 <tr>
                     
    <th>Name</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>Password</th>
    <th>Age</th>
  </tr>
  <tr>
                    <td>
                        {this.state.userName}
                    </td>
                    <td>
                        {this.state.userLastName}
                    </td>
                    <td>
                        {this.state.userEmail}
                    </td>
                    <td>
                        {this.state.userPass}
                    </td>
                    <td>
                        {this.state.age}
                    </td>
  </tr>
  </table>
  :null    } </div>
        )
    }
}
