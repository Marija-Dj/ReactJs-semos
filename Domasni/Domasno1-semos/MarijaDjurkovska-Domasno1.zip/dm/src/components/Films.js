import React from 'react'

export class Films extends React.Component {
    render() 
    {
        console.log(this.props)
        return (
            <div id="films">
                <ol>
                    {
                        this.props.films.map((films, i)=>
                        {
                            return(
                                <li key={i}>
                                    <table>
                                        <tr width="500" height="20">
                                        <th> {films.naslov}</th>
                                        </tr>
                                
                                <tr>
                                  <td>
                                  <img src={films.slika} alt="film poster" width="200" height="300"></img> 
                                  </td>
                                    
                                     <td width="500" height="300">
                                    <span>Data: {films.data}</span>
                                    <br/>
                                    <p> {films.genrePlot}</p>
                                    <br/>
                                    <a href={films.imdbUrl}>IMDB </a>        
                                    </td>
                                   </tr>

                                  </table>
                                  <br/>
                                </li>
                            )
                        })
                    }
                </ol>
                
            </div>
        )
    }
}

