import React from 'react';
import {Films} from './Films';


export  class App extends React.Component {
  render() {
    var films=[
      {
        naslov:"Avengers: Endgame",
         data:"26 Aprol 2019", 
         genrePlot:"Action", 
         imdbUrl:"imdb.com/title/tt4154796/?ref_=fn_al_tt_1",
          slika:"https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQA_-tL18_rj9zEcjN6n41NEaJm-kRNF9UeOtvksZ4z_OW6jRA9" },
      {
        naslov:"Once Upon a Time in Hollywood",
         data:"July 24, 2019",
         genrePlot:"Comedy",
         imdbUrl:"https://www.imdb.com/title/tt7131622/",
         slika:"https://m.media-amazon.com/images/M/MV5BOTg4ZTNkZmUtMzNlZi00YmFjLTk1MmUtNWQwNTM0YjcyNTNkXkEyXkFqcGdeQXVyNjg2NjQwMDQ@._V1_SY1000_CR0,0,674,1000_AL_.jpg"},
      {
        naslov:"Ford v Ferrari",
         data:"August 30, 2019 ",
        genrePlot:"Action", 
        imdbUrl:"https://www.imdb.com/title/tt1950186/", 
        slika:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRB31VxqlQrKXHILkOIQ2VTZbgDeddYUy6FeqESAGAeCYwY5062" },
      {
        naslov:"John Wick: Chapter 3 – Parabellum", 
        data:"May 9, 2019", 
        genrePlot:"Action", 
        imdbUrl:"https://www.imdb.com/title/tt6146586/",
        slika:"https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTaABFJr_eVRUhtaPnKfihePqqNsJjcGvZ62OgxCv6wjXn-XgGC"
      },
      {
        naslov:"Aladdin", 
        data:"May 08 2019", 
        genrePlot:"Adventure, Family, Fantasy ", 
        imdbUrl:"https://www.imdb.com/title/tt6139732/",  
        slika:"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcReXTb0ovI3Y0LCEEg2_VEyIqm73i-PDegxJaJaIBZh92s_LFK4"},
    ];
    return (
      <div>
        <Films
        films={films}
        />
      </div>
    )
  }
}

