import React from 'react'

export class Albums extends React.Component {
    render() {
        return (
            <div>
                                {
                    this.props.album.length>1?
                    <table border= "5">
                        <thead>
                            <tr>
                                <th>
                                    UserId
                                </th>
                                <th>
                                    Id
                                </th>
                                <th>
                                    Title
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.props.album.map((album, i)=>{
                                    return(
                                        <tr key={i}>
                                            <td>{album.userId}</td>
                                            <td>{album.id}</td>
                                            <td>{album.title}
                                        </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>  : <h2>Loading..</h2>}
            </div>
        )
    }
}
