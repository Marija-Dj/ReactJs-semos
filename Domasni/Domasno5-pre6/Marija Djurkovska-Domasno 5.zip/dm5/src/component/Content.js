import React from 'react'

export class Content extends React.Component {
    render() {
        return (
            <div class="Links">
  <a target="_blank" href="/content/albums"> Visit Albume </a><br/>
  <a target="_blank" href="/content/posts"> Visit Posts </a><br/>
  <a target="_blank" href="/content/todos"> Visit To Do </a>


            </div>                
        )
    }
}
