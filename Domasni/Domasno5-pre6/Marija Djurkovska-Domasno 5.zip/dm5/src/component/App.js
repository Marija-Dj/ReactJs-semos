import React from 'react';
import './App.css';
import {Switch, Route} from 'react-router-dom';
import {Home} from './Home';
import { Content } from './Content';
import { Albums } from './Albums';
import { Posts } from './Posts';
import { Todos } from './Todos';
import { Nav } from './Nav';
import axios from 'axios';

export class App extends React.Component {
  constructor(props){
    super();
    this.state={
      albums:[],
      posts:[],
      todos:[]
    }
  }
  componentDidMount(){
    this.fatchAlbums();
    this.fatchPosts();
    this.fatchToDos();
  }

  fatchAlbums=()=>{
    axios({
      url:'https://jsonplaceholder.typicode.com/albums',
      method:'GET'
    })
    .then(res=>{
      this.setState({albums:res.data})
    })
    .catch(err=>{
      alert(err)
    })
    }
  fatchPosts=()=>{
  axios({
    url:'https://jsonplaceholder.typicode.com/posts',
    method:'GET'
  })
  .then(res=>{
    this.setState({posts:res.data})
  })
  .catch(err=>{
    alert(err)
  })
  }
  fatchToDos=()=>{
    axios({
      url:'https://jsonplaceholder.typicode.com/todos',
      method:'GET'
    })
    .then(res=>{
      this.setState({todos:res.data})
    })
    .catch(err=>{
      alert(err)
    })
    }

  render() {
    return (
      <div>
        <Nav/>
        <Switch>
          <Route exact path="/home" component={Home}/>
          <Route exact path="/content" component={Content}/>
          <Route  path="/content/albums" render={()=>{return <Albums album={this.state.albums} />}}/>
          <Route  path="/content/posts" render={()=>{return <Posts post={this.state.posts} />}}/>
          <Route  exact path="/content/todos" render={()=>{return <Todos todo={this.state.todos} />}}/>
        </Switch>
      </div>
    )
  }
}

