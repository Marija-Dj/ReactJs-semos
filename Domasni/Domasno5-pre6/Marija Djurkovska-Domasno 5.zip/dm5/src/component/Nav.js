import React from 'react'
//import {} from 'react-r'
import {Link} from 'react-router-dom';

export class Nav extends React.Component {
    render() {
        return (
            <div>
               <ul>
                  <li><Link to="/home">Home</Link></li>
                  <li><Link to="/content">Content</Link></li>
                  <li><Link to="/content/albums">Albums</Link></li>
                  <li><Link to="/content/posts">Posts</Link></li>
                  <li><Link to="/content/todos">Todos</Link></li>
                  
              </ul>
            </div>
        )
    }
}
