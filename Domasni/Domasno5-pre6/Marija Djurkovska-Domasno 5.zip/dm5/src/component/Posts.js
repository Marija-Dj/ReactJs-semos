import React from 'react'

export class Posts extends React.Component {
    render() {
        return (
            <div>
                                                {
                    this.props.post.length>1?
                    <table border= "5">
                        <thead>
                            <tr>
                                <th>
                                    UserId
                                </th>
                                <th>
                                    Id
                                </th>
                                <th>
                                    Title
                                </th>
                                <th>body</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.props.post.map((post, i)=>{
                                    return(
                                        <tr key={i}>
                                            <td>{post.userId}</td>
                                            <td>{post.id}</td>
                                            <td>{post.title}</td>
                                    <td>{post.body}</td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>  : <h2>Loading..</h2>}
            </div>
        )
    }
}
