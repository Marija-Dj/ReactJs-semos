import React from 'react'

export class Todos extends React.Component {
    render() {
        return (
            <div>
                                          {
                    this.props.todo.length>1?
                    <table border= "5">
                        <thead>
                            <tr>
                                <th>
                                    UserId
                                </th>
                                <th>
                                    Id
                                </th>
                                <th>
                                    Title
                                </th>
                                <th>Completed</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.props.todo.map((todo, i)=>{
                                    return(
                                        <tr key={i}>
                                            <td>{todo.userId}</td>
                                            <td>{todo.id}</td>
                                            <td>{todo.title}</td>
                                           <td> <input //defaultChecked
                                    type="checkbox"
                                    //value={todo.completed}
                                    checked={todo.completed}
                                    /></td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>  : <h2>Loading..</h2>}
            </div>
        )
    }
}
